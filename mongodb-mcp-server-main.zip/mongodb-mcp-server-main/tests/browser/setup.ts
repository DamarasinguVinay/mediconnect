import { Buffer } from "buffer";

// Make Buffer available globally for browser tests
globalThis.Buffer = Buffer;
