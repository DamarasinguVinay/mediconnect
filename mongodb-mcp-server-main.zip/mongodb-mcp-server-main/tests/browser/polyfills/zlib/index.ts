export function inflate() {
    // noop
}
export function deflate() {
    // noop
}
export default { inflate, deflate };
