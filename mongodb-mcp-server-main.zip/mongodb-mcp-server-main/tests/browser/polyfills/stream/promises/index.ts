export function pipeline(): Promise<void> {
    throw new Error("Not supported in browser environment");
}
