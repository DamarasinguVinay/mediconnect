throw new Error("Module not supported in the browser environment");
