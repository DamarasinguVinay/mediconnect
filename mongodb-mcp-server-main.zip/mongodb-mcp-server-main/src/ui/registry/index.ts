export { UIRegistry } from "./registry.js";
